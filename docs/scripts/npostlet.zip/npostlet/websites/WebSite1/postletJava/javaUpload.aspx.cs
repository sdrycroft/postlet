using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class postletJava_javaUpload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Response.Write("RECEIVING:");

        string _uploadDir = "[PATH TO UPLOAD DIRECTORY]";
        string _path = Path.Combine(_uploadDir, Request.Files["userfile"].FileName);
        try
        {
            Request.Files["userfile"].SaveAs(_path);
            Response.Write("YES");
        }
        catch
        {
            Response.Write("NO");
        }

        Response.Flush();
    }
}
