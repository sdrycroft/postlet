using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

        /* uncomment this line to see how you can pass in parameters to your page. 
        PostletControl1.DestinationHandler = "http://www.mysite.com/postletJava/javaUpload.aspx?scott=cool";
         */

        /* this was cool test... it even picks up the cookies
        Response.Cookies.Add(new HttpCookie("albumid", "asdfasdfasdf"));
         */
    }
}
