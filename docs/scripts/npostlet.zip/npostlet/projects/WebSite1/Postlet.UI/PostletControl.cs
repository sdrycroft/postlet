using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Postlet.UI
{
    //[DefaultProperty("Text")]
    [ToolboxData("<{0}:PostletControl runat=server></{0}:PostletControl>")]
    public class PostletControl : Panel
    {
        HtmlGenericControl _applet = new HtmlGenericControl("applet");
        string _archive = string.Empty;
        string _destination = string.Empty;
        string _endpage = string.Empty;



        protected override void OnPreRender(EventArgs e)
        {
            CreateApplet();
            base.OnPreRender(e);
        }

        public string Archive
        {
            get
            {
                return _archive;
            }
            set
            {
                _archive = value;
            }
        }

        public string DestinationHandler
        {
            get
            {
                return _destination;
            }
            set
            {
                _destination = value;
            }
        }
        public string EndPageURL
        {
            get
            {
                return _endpage;
            }
            set
            {
                _endpage = value;
            }
        }


        private void CreateApplet()
        {
            _applet = new HtmlGenericControl("applet");
            _applet.Attributes.Add("width", base.Width.Value.ToString());
            _applet.Attributes.Add("height", base.Height.Value.ToString());
            _applet.Attributes.Add("MAYSCRIPT", string.Empty);

            _applet.Controls.Add(CreateParam("code", "Main.class"));
            _applet.Controls.Add(CreateParam("archive", _archive));
            _applet.Controls.Add(CreateParam("name", "Multiple file uploader"));
            _applet.Controls.Add(CreateParam("type", "application/x-java-applet;version=1.3"));
            _applet.Controls.Add(CreateParam("scriptable", "false"));
            _applet.Controls.Add(CreateParam("destination", _destination));
            _applet.Controls.Add(CreateParam("endpage", _endpage));
            _applet.Controls.Add(CreateParam("red", "255"));
            _applet.Controls.Add(CreateParam("green", "255"));
            _applet.Controls.Add(CreateParam("blue", "255"));
            _applet.Controls.Add(CreateParam("redheader", "200"));
            _applet.Controls.Add(CreateParam("blueheader", "200"));

            this.Controls.Clear();

            this.Controls.Add(_applet);
            
        }
        private HtmlGenericControl CreateParam(string name, string value)
        {
            HtmlGenericControl _param = new HtmlGenericControl("param");
            _param.Attributes.Add("name", name);
            _param.Attributes.Add("value", value);
            return _param;
        }
    }
}
